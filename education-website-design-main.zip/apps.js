let logiForm = document.querySelector('.login-form');
document.querySelector('#login-btn').onclick = () =>{
    logiForm.classList.toggle('active');
    navbar.classList.remove('active');
}


let navbar = document.querySelector('.navbar');

document.querySelector('#menu-btn').onclick = () =>{
    navbar.classList.toggle('active');
    logiForm.classList.remove('active');
}

window.onscroll = () =>{
    logiForm.classList.remove('active');
    navbar.classList.remove('active');
}